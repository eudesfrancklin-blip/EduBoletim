# EduBoletim - Sistema de Gestão Escolar

## Descrição

**EduBoletim** é um sistema web de gestão acadêmica desenvolvido em **Python/Django** que centraliza e automatiza os processos de administração escolar. A plataforma foi concebida para resolver a ineficiência e falta de centralização na administração de dados escolares, oferecendo uma solução integrada para gestores, professores e, futuramente, pais e alunos.

## Funcionalidades Principais

### 1. **Cadastros Estruturados**
- Escolas
- Séries (ex: 1º Ano, 2º Ano)
- Turmas
- Alunos
- Disciplinas
- Usuários com diferentes perfis

### 2. **Lançamento de Dados Acadêmicos**
- Registro de notas por disciplina e período
- Controle de frequência de alunos
- Registro de conteúdos ministrados

### 3. **Cálculo Automático de Médias**
- Cálculo automático de médias por disciplina
- Cálculo da média geral do aluno
- Definição automática da situação do aluno (aprovado/reprovado)

### 4. **Boletim Digital**
- Visualização consolidada do desempenho acadêmico
- Layout claro e informativo
- Acesso rápido e seguro às informações

### 5. **Controle de Acesso**
Hierarquia de permissões para diferentes perfis de usuários:
- **Super Usuário**: Gestão geral da plataforma
- **Institucional**: Gestão de escolas, séries, turmas e alunos
- **Professor**: Lançamento de notas e frequência

## Tecnologias Utilizadas

- **Backend**: Python 3.11 + Django 5.2
- **Banco de Dados**: SQLite (padrão do Django)
- **Frontend**: HTML5 + CSS3
- **Autenticação**: Sistema de autenticação nativo do Django

## Instalação e Configuração

### Pré-requisitos
- Python 3.8 ou superior
- pip (gerenciador de pacotes Python)

### Passos para Instalação

1. **Clone o repositório** (ou extraia o arquivo ZIP):
   ```bash
   cd eduboletim_project
   ```

2. **Crie um ambiente virtual**:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # No Windows: venv\Scripts\activate
   ```

3. **Instale as dependências**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Aplique as migrações do banco de dados**:
   ```bash
   python manage.py migrate
   ```

5. **Crie um superusuário** (opcional, se não foi criado automaticamente):
   ```bash
   python manage.py createsuperuser
   ```

6. **Inicie o servidor de desenvolvimento**:
   ```bash
   python manage.py runserver
   ```

7. **Acesse a aplicação**:
   - URL: `http://localhost:8000`
   - Painel Administrativo: `http://localhost:8000/admin`

## Credenciais Padrão

Um superusuário padrão foi criado automaticamente:
- **Usuário**: `admin`
- **Senha**: `admin123`
- **Tipo**: Super Usuário

**Importante**: Altere a senha do superusuário após o primeiro acesso em produção!

## Estrutura do Projeto

```
eduboletim_project/
├── academico/                      # App principal do Django
│   ├── migrations/                 # Migrações do banco de dados
│   ├── templates/academico/        # Templates HTML
│   │   ├── base.html              # Template base
│   │   ├── login.html             # Página de login
│   │   ├── home.html              # Página inicial
│   │   ├── escolas/               # Templates de Escolas
│   │   ├── series/                # Templates de Séries
│   │   ├── turmas/                # Templates de Turmas
│   │   ├── alunos/                # Templates de Alunos
│   │   ├── disciplinas/           # Templates de Disciplinas
│   │   ├── notas/                 # Templates de Notas
│   │   ├── frequencias/           # Templates de Frequências
│   │   └── boletim.html           # Boletim Digital
│   ├── admin.py                    # Configuração do painel administrativo
│   ├── models.py                   # Modelos de dados
│   ├── views.py                    # Controladores (views)
│   ├── urls.py                     # Roteamento de URLs
│   ├── forms.py                    # Formulários Django
│   └── apps.py                     # Configuração da app
├── eduboletim_project/             # Configurações do projeto
│   ├── settings.py                 # Configurações do Django
│   ├── urls.py                     # URLs principais
│   └── wsgi.py                     # Configuração WSGI
├── manage.py                       # Script de gerenciamento do Django
├── requirements.txt                # Dependências do projeto
├── README.md                       # Este arquivo
└── db.sqlite3                      # Banco de dados SQLite
```

## Modelos de Dados

### Usuario
Modelo customizado que estende o usuário padrão do Django com:
- `tipo_usuario`: Super Usuário, Institucional ou Professor

### Escola
Representa uma instituição de ensino.

### Serie
Representa uma série (ex: 1º Ano, 2º Ano) dentro de uma escola.

### Turma
Representa uma turma dentro de uma série.

### Aluno
Representa um aluno matriculado em uma turma.

### Disciplina
Representa uma disciplina (ex: Matemática, Português).

### Professor
Representa um professor e suas disciplinas.

### Nota
Registra a nota de um aluno em uma disciplina em um período específico.

### Frequencia
Registra a presença/ausência de um aluno em uma disciplina em uma data específica.

## Fluxo de Uso

1. **Login**: Acesse o sistema com suas credenciais
2. **Cadastro de Dados**: Crie escolas, séries, turmas, alunos e disciplinas
3. **Alocação de Professores**: Associe professores às disciplinas
4. **Lançamento de Notas**: Professores lançam notas dos alunos
5. **Registro de Frequência**: Professores registram frequência
6. **Visualização de Boletim**: Consulte o desempenho acadêmico dos alunos

## Cálculo de Médias

O sistema calcula automaticamente:
- **Média por Disciplina**: Média aritmética simples das notas
- **Média Geral**: Média de todas as disciplinas
- **Situação do Aluno**: Aprovado (média ≥ 6) ou Reprovado (média < 6)

## Futuras Melhorias

De acordo com o documento de especificação, as seguintes funcionalidades estão planejadas para versões futuras:

- Portal para pais e alunos acessarem boletins
- Módulo de comunicação interna
- Geração de relatórios gráficos de desempenho
- Integração com sistemas de pagamento
- Aplicativo mobile

## Segurança

- Autenticação obrigatória para acessar o sistema
- Senhas criptografadas no banco de dados
- Proteção contra CSRF (Cross-Site Request Forgery)
- Validação de entrada de dados

## Suporte

Para dúvidas ou problemas, entre em contato com a equipe de desenvolvimento:
- Chintia Barbosa de Souza: souzachintia2021@gmail.com
- Eudes Franklin Alves Lisboa: eudesfrancklin@gmail.com
- Laila Maria Souza de Oliveira: lailamariasouzadeoliveira726@gmail.com

## Licença

Este projeto foi desenvolvido como trabalho integrador para a disciplina de Tecnologia em Sistemas para Internet da Universidade Estadual do Piauí (UESPI).

## Versão

**Versão 1.0** - Dezembro de 2025

---

**Desenvolvido com ❤️ pela Equipe EduBoletim**
