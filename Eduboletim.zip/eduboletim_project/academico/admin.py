from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Usuario, Escola, Serie, Turma, Aluno, Disciplina, Professor, Nota, Frequencia

# Registrar o modelo de usuário customizado
@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ('Tipo de Usuário', {'fields': ('tipo_usuario',)}),
    )
    list_display = ('username', 'email', 'first_name', 'last_name', 'tipo_usuario')

# Registrar os outros modelos
@admin.register(Escola)
class EscolaAdmin(admin.ModelAdmin):
    list_display = ('nome',)

@admin.register(Serie)
class SerieAdmin(admin.ModelAdmin):
    list_display = ('nome', 'escola')

@admin.register(Turma)
class TurmaAdmin(admin.ModelAdmin):
    list_display = ('nome', 'serie')

@admin.register(Aluno)
class AlunoAdmin(admin.ModelAdmin):
    list_display = ('nome', 'turma')

@admin.register(Disciplina)
class DisciplinaAdmin(admin.ModelAdmin):
    list_display = ('nome',)

@admin.register(Professor)
class ProfessorAdmin(admin.ModelAdmin):
    list_display = ('usuario', 'get_disciplinas')
    
    def get_disciplinas(self, obj):
        return ', '.join([d.nome for d in obj.disciplinas.all()])
    get_disciplinas.short_description = 'Disciplinas'

@admin.register(Nota)
class NotaAdmin(admin.ModelAdmin):
    list_display = ('aluno', 'disciplina', 'valor', 'periodo')

@admin.register(Frequencia)
class FrequenciaAdmin(admin.ModelAdmin):
    list_display = ('aluno', 'disciplina', 'data', 'presente')
