# academico/forms.py

from django import forms
from .models import Usuario, Escola, Serie, Turma, Aluno, Disciplina, Professor, Nota, Frequencia

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['username', 'email', 'first_name', 'last_name', 'tipo_usuario']

class EscolaForm(forms.ModelForm):
    class Meta:
        model = Escola
        fields = ['nome']

class SerieForm(forms.ModelForm):
    class Meta:
        model = Serie
        fields = ['nome', 'escola']

class TurmaForm(forms.ModelForm):
    class Meta:
        model = Turma
        fields = ['nome', 'serie']

class AlunoForm(forms.ModelForm):
    class Meta:
        model = Aluno
        fields = ['nome', 'turma']

class DisciplinaForm(forms.ModelForm):
    class Meta:
        model = Disciplina
        fields = ['nome']

class NotaForm(forms.ModelForm):
    class Meta:
        model = Nota
        fields = ['aluno', 'disciplina', 'valor', 'periodo']

class FrequenciaForm(forms.ModelForm):
    class Meta:
        model = Frequencia
        fields = ['aluno', 'disciplina', 'presente', 'data']
