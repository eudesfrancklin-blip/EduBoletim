# academico/models.py

from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission

class Usuario(AbstractUser):
    ''' Modelo de usuário personalizado que estende o usuário padrão do Django. '''
    
    # Adiciona um campo 'tipo_usuario' para diferenciar os perfis de usuário.
    TIPO_USUARIO_CHOICES = (
        ('super', 'Super Usuário'),
        ('institucional', 'Institucional'),
        ('professor', 'Professor'),
    )
    tipo_usuario = models.CharField(max_length=15, choices=TIPO_USUARIO_CHOICES, default='professor')

    # Adiciona related_name para evitar conflitos com o modelo de usuário padrão do Django.
    groups = models.ManyToManyField(
        Group,
        verbose_name='groups',
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
        related_name="usuario_set",
        related_query_name="user",
    )
    user_permissions = models.ManyToManyField(
        Permission,
        verbose_name='user permissions',
        blank=True,
        help_text='Specific permissions for this user.',
        related_name="usuario_set",
        related_query_name="user",
    )

class Escola(models.Model):
    ''' Modelo para representar uma escola. '''
    nome = models.CharField(max_length=255)
    # Adicione outros campos relevantes para a escola, como endereço, etc.

    def __str__(self):
        return self.nome

class Serie(models.Model):
    ''' Modelo para representar uma série (ex: 1º Ano, 2º Ano). '''
    nome = models.CharField(max_length=100)
    escola = models.ForeignKey(Escola, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.nome} - {self.escola.nome}"

class Turma(models.Model):
    ''' Modelo para representar uma turma. '''
    nome = models.CharField(max_length=100)
    serie = models.ForeignKey(Serie, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.nome} - {self.serie.nome}"

class Aluno(models.Model):
    ''' Modelo para representar um aluno. '''
    nome = models.CharField(max_length=255)
    turma = models.ForeignKey(Turma, on_delete=models.CASCADE)

    def __str__(self):
        return self.nome

class Disciplina(models.Model):
    ''' Modelo para representar uma disciplina. '''
    nome = models.CharField(max_length=100)

    def __str__(self):
        return self.nome

class Professor(models.Model):
    ''' Modelo para representar um professor. '''
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE)
    disciplinas = models.ManyToManyField(Disciplina)

    def __str__(self):
        return self.usuario.get_full_name() or self.usuario.username

class Nota(models.Model):
    ''' Modelo para representar a nota de um aluno em uma disciplina. '''
    aluno = models.ForeignKey(Aluno, on_delete=models.CASCADE)
    disciplina = models.ForeignKey(Disciplina, on_delete=models.CASCADE)
    valor = models.DecimalField(max_digits=5, decimal_places=2)
    periodo = models.CharField(max_length=50)  # Ex: '1º Bimestre', '2º Semestre'

    def __str__(self):
        return f"{self.aluno.nome} - {self.disciplina.nome}: {self.valor}"

class Frequencia(models.Model):
    ''' Modelo para representar a frequência de um aluno em uma disciplina. '''
    aluno = models.ForeignKey(Aluno, on_delete=models.CASCADE)
    disciplina = models.ForeignKey(Disciplina, on_delete=models.CASCADE)
    presente = models.BooleanField(default=True)
    data = models.DateField()

    def __str__(self):
        return f"{self.aluno.nome} - {self.disciplina.nome} - {'Presente' if self.presente else 'Ausente'}"
