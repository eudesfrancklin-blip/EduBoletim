# academico/urls.py

from django.urls import path
from . import views

urlpatterns = [
    # Home
    path('', views.home, name='home'),
    
    # Autenticação
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    # Cadastros (Institucional)
    path('escolas/', views.lista_escolas, name='lista_escolas'),
    path('escolas/criar/', views.criar_escola, name='criar_escola'),
    path('escolas/<int:id>/editar/', views.editar_escola, name='editar_escola'),
    path('escolas/<int:id>/deletar/', views.deletar_escola, name='deletar_escola'),
    
    path('series/', views.lista_series, name='lista_series'),
    path('series/criar/', views.criar_serie, name='criar_serie'),
    path('series/<int:id>/editar/', views.editar_serie, name='editar_serie'),
    path('series/<int:id>/deletar/', views.deletar_serie, name='deletar_serie'),
    
    path('turmas/', views.lista_turmas, name='lista_turmas'),
    path('turmas/criar/', views.criar_turma, name='criar_turma'),
    path('turmas/<int:id>/editar/', views.editar_turma, name='editar_turma'),
    path('turmas/<int:id>/deletar/', views.deletar_turma, name='deletar_turma'),
    
    path('alunos/', views.lista_alunos, name='lista_alunos'),
    path('alunos/criar/', views.criar_aluno, name='criar_aluno'),
    path('alunos/<int:id>/editar/', views.editar_aluno, name='editar_aluno'),
    path('alunos/<int:id>/deletar/', views.deletar_aluno, name='deletar_aluno'),
    
    path('disciplinas/', views.lista_disciplinas, name='lista_disciplinas'),
    path('disciplinas/criar/', views.criar_disciplina, name='criar_disciplina'),
    path('disciplinas/<int:id>/editar/', views.editar_disciplina, name='editar_disciplina'),
    path('disciplinas/<int:id>/deletar/', views.deletar_disciplina, name='deletar_disciplina'),
    
    # Notas e Frequência (Professor)
    path('notas/', views.lista_notas, name='lista_notas'),
    path('notas/criar/', views.criar_nota, name='criar_nota'),
    path('notas/<int:id>/editar/', views.editar_nota, name='editar_nota'),
    path('notas/<int:id>/deletar/', views.deletar_nota, name='deletar_nota'),
    
    path('frequencias/', views.lista_frequencias, name='lista_frequencias'),
    path('frequencias/criar/', views.criar_frequencia, name='criar_frequencia'),
    path('frequencias/<int:id>/editar/', views.editar_frequencia, name='editar_frequencia'),
    path('frequencias/<int:id>/deletar/', views.deletar_frequencia, name='deletar_frequencia'),
    
    # Boletim
    path('boletim/<int:aluno_id>/', views.boletim, name='boletim'),
]
