from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Avg
from .models import Usuario, Escola, Serie, Turma, Aluno, Disciplina, Professor, Nota, Frequencia
from .forms import (
    UsuarioForm, EscolaForm, SerieForm, TurmaForm, AlunoForm, 
    DisciplinaForm, NotaForm, FrequenciaForm
)

# ======================== AUTENTICAÇÃO ========================

def login_view(request):
    """View para login de usuários."""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Usuário ou senha inválidos.')
    return render(request, 'academico/login.html')

def logout_view(request):
    """View para logout de usuários."""
    logout(request)
    return redirect('login')

# ======================== HOME ========================

@login_required(login_url='login')
def home(request):
    """View da página inicial."""
    context = {
        'usuario': request.user,
    }
    return render(request, 'academico/home.html', context)

# ======================== ESCOLAS ========================

@login_required(login_url='login')
def lista_escolas(request):
    """Lista todas as escolas."""
    escolas = Escola.objects.all()
    return render(request, 'academico/escolas/lista.html', {'escolas': escolas})

@login_required(login_url='login')
def criar_escola(request):
    """Cria uma nova escola."""
    if request.method == 'POST':
        form = EscolaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Escola criada com sucesso!')
            return redirect('lista_escolas')
    else:
        form = EscolaForm()
    return render(request, 'academico/escolas/form.html', {'form': form, 'titulo': 'Criar Escola'})

@login_required(login_url='login')
def editar_escola(request, id):
    """Edita uma escola existente."""
    escola = get_object_or_404(Escola, id=id)
    if request.method == 'POST':
        form = EscolaForm(request.POST, instance=escola)
        if form.is_valid():
            form.save()
            messages.success(request, 'Escola atualizada com sucesso!')
            return redirect('lista_escolas')
    else:
        form = EscolaForm(instance=escola)
    return render(request, 'academico/escolas/form.html', {'form': form, 'titulo': 'Editar Escola'})

@login_required(login_url='login')
def deletar_escola(request, id):
    """Deleta uma escola."""
    escola = get_object_or_404(Escola, id=id)
    if request.method == 'POST':
        escola.delete()
        messages.success(request, 'Escola deletada com sucesso!')
        return redirect('lista_escolas')
    return render(request, 'academico/confirmar_delecao.html', {'objeto': escola})

# ======================== SÉRIES ========================

@login_required(login_url='login')
def lista_series(request):
    """Lista todas as séries."""
    series = Serie.objects.all()
    return render(request, 'academico/series/lista.html', {'series': series})

@login_required(login_url='login')
def criar_serie(request):
    """Cria uma nova série."""
    if request.method == 'POST':
        form = SerieForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Série criada com sucesso!')
            return redirect('lista_series')
    else:
        form = SerieForm()
    return render(request, 'academico/series/form.html', {'form': form, 'titulo': 'Criar Série'})

@login_required(login_url='login')
def editar_serie(request, id):
    """Edita uma série existente."""
    serie = get_object_or_404(Serie, id=id)
    if request.method == 'POST':
        form = SerieForm(request.POST, instance=serie)
        if form.is_valid():
            form.save()
            messages.success(request, 'Série atualizada com sucesso!')
            return redirect('lista_series')
    else:
        form = SerieForm(instance=serie)
    return render(request, 'academico/series/form.html', {'form': form, 'titulo': 'Editar Série'})

@login_required(login_url='login')
def deletar_serie(request, id):
    """Deleta uma série."""
    serie = get_object_or_404(Serie, id=id)
    if request.method == 'POST':
        serie.delete()
        messages.success(request, 'Série deletada com sucesso!')
        return redirect('lista_series')
    return render(request, 'academico/confirmar_delecao.html', {'objeto': serie})

# ======================== TURMAS ========================

@login_required(login_url='login')
def lista_turmas(request):
    """Lista todas as turmas."""
    turmas = Turma.objects.all()
    return render(request, 'academico/turmas/lista.html', {'turmas': turmas})

@login_required(login_url='login')
def criar_turma(request):
    """Cria uma nova turma."""
    if request.method == 'POST':
        form = TurmaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Turma criada com sucesso!')
            return redirect('lista_turmas')
    else:
        form = TurmaForm()
    return render(request, 'academico/turmas/form.html', {'form': form, 'titulo': 'Criar Turma'})

@login_required(login_url='login')
def editar_turma(request, id):
    """Edita uma turma existente."""
    turma = get_object_or_404(Turma, id=id)
    if request.method == 'POST':
        form = TurmaForm(request.POST, instance=turma)
        if form.is_valid():
            form.save()
            messages.success(request, 'Turma atualizada com sucesso!')
            return redirect('lista_turmas')
    else:
        form = TurmaForm(instance=turma)
    return render(request, 'academico/turmas/form.html', {'form': form, 'titulo': 'Editar Turma'})

@login_required(login_url='login')
def deletar_turma(request, id):
    """Deleta uma turma."""
    turma = get_object_or_404(Turma, id=id)
    if request.method == 'POST':
        turma.delete()
        messages.success(request, 'Turma deletada com sucesso!')
        return redirect('lista_turmas')
    return render(request, 'academico/confirmar_delecao.html', {'objeto': turma})

# ======================== ALUNOS ========================

@login_required(login_url='login')
def lista_alunos(request):
    """Lista todos os alunos."""
    alunos = Aluno.objects.all()
    return render(request, 'academico/alunos/lista.html', {'alunos': alunos})

@login_required(login_url='login')
def criar_aluno(request):
    """Cria um novo aluno."""
    if request.method == 'POST':
        form = AlunoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Aluno criado com sucesso!')
            return redirect('lista_alunos')
    else:
        form = AlunoForm()
    return render(request, 'academico/alunos/form.html', {'form': form, 'titulo': 'Criar Aluno'})

@login_required(login_url='login')
def editar_aluno(request, id):
    """Edita um aluno existente."""
    aluno = get_object_or_404(Aluno, id=id)
    if request.method == 'POST':
        form = AlunoForm(request.POST, instance=aluno)
        if form.is_valid():
            form.save()
            messages.success(request, 'Aluno atualizado com sucesso!')
            return redirect('lista_alunos')
    else:
        form = AlunoForm(instance=aluno)
    return render(request, 'academico/alunos/form.html', {'form': form, 'titulo': 'Editar Aluno'})

@login_required(login_url='login')
def deletar_aluno(request, id):
    """Deleta um aluno."""
    aluno = get_object_or_404(Aluno, id=id)
    if request.method == 'POST':
        aluno.delete()
        messages.success(request, 'Aluno deletado com sucesso!')
        return redirect('lista_alunos')
    return render(request, 'academico/confirmar_delecao.html', {'objeto': aluno})

# ======================== DISCIPLINAS ========================

@login_required(login_url='login')
def lista_disciplinas(request):
    """Lista todas as disciplinas."""
    disciplinas = Disciplina.objects.all()
    return render(request, 'academico/disciplinas/lista.html', {'disciplinas': disciplinas})

@login_required(login_url='login')
def criar_disciplina(request):
    """Cria uma nova disciplina."""
    if request.method == 'POST':
        form = DisciplinaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Disciplina criada com sucesso!')
            return redirect('lista_disciplinas')
    else:
        form = DisciplinaForm()
    return render(request, 'academico/disciplinas/form.html', {'form': form, 'titulo': 'Criar Disciplina'})

@login_required(login_url='login')
def editar_disciplina(request, id):
    """Edita uma disciplina existente."""
    disciplina = get_object_or_404(Disciplina, id=id)
    if request.method == 'POST':
        form = DisciplinaForm(request.POST, instance=disciplina)
        if form.is_valid():
            form.save()
            messages.success(request, 'Disciplina atualizada com sucesso!')
            return redirect('lista_disciplinas')
    else:
        form = DisciplinaForm(instance=disciplina)
    return render(request, 'academico/disciplinas/form.html', {'form': form, 'titulo': 'Editar Disciplina'})

@login_required(login_url='login')
def deletar_disciplina(request, id):
    """Deleta uma disciplina."""
    disciplina = get_object_or_404(Disciplina, id=id)
    if request.method == 'POST':
        disciplina.delete()
        messages.success(request, 'Disciplina deletada com sucesso!')
        return redirect('lista_disciplinas')
    return render(request, 'academico/confirmar_delecao.html', {'objeto': disciplina})

# ======================== NOTAS ========================

@login_required(login_url='login')
def lista_notas(request):
    """Lista todas as notas."""
    notas = Nota.objects.all()
    return render(request, 'academico/notas/lista.html', {'notas': notas})

@login_required(login_url='login')
def criar_nota(request):
    """Cria uma nova nota."""
    if request.method == 'POST':
        form = NotaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Nota criada com sucesso!')
            return redirect('lista_notas')
    else:
        form = NotaForm()
    return render(request, 'academico/notas/form.html', {'form': form, 'titulo': 'Criar Nota'})

@login_required(login_url='login')
def editar_nota(request, id):
    """Edita uma nota existente."""
    nota = get_object_or_404(Nota, id=id)
    if request.method == 'POST':
        form = NotaForm(request.POST, instance=nota)
        if form.is_valid():
            form.save()
            messages.success(request, 'Nota atualizada com sucesso!')
            return redirect('lista_notas')
    else:
        form = NotaForm(instance=nota)
    return render(request, 'academico/notas/form.html', {'form': form, 'titulo': 'Editar Nota'})

@login_required(login_url='login')
def deletar_nota(request, id):
    """Deleta uma nota."""
    nota = get_object_or_404(Nota, id=id)
    if request.method == 'POST':
        nota.delete()
        messages.success(request, 'Nota deletada com sucesso!')
        return redirect('lista_notas')
    return render(request, 'academico/confirmar_delecao.html', {'objeto': nota})

# ======================== FREQUÊNCIAS ========================

@login_required(login_url='login')
def lista_frequencias(request):
    """Lista todas as frequências."""
    frequencias = Frequencia.objects.all()
    return render(request, 'academico/frequencias/lista.html', {'frequencias': frequencias})

@login_required(login_url='login')
def criar_frequencia(request):
    """Cria uma nova frequência."""
    if request.method == 'POST':
        form = FrequenciaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Frequência criada com sucesso!')
            return redirect('lista_frequencias')
    else:
        form = FrequenciaForm()
    return render(request, 'academico/frequencias/form.html', {'form': form, 'titulo': 'Criar Frequência'})

@login_required(login_url='login')
def editar_frequencia(request, id):
    """Edita uma frequência existente."""
    frequencia = get_object_or_404(Frequencia, id=id)
    if request.method == 'POST':
        form = FrequenciaForm(request.POST, instance=frequencia)
        if form.is_valid():
            form.save()
            messages.success(request, 'Frequência atualizada com sucesso!')
            return redirect('lista_frequencias')
    else:
        form = FrequenciaForm(instance=frequencia)
    return render(request, 'academico/frequencias/form.html', {'form': form, 'titulo': 'Editar Frequência'})

@login_required(login_url='login')
def deletar_frequencia(request, id):
    """Deleta uma frequência."""
    frequencia = get_object_or_404(Frequencia, id=id)
    if request.method == 'POST':
        frequencia.delete()
        messages.success(request, 'Frequência deletada com sucesso!')
        return redirect('lista_frequencias')
    return render(request, 'academico/confirmar_delecao.html', {'objeto': frequencia})

# ======================== BOLETIM ========================

@login_required(login_url='login')
def boletim(request, aluno_id):
    """Exibe o boletim digital de um aluno."""
    aluno = get_object_or_404(Aluno, id=aluno_id)
    notas = Nota.objects.filter(aluno=aluno)
    frequencias = Frequencia.objects.filter(aluno=aluno)
    
    # Calcular média por disciplina
    disciplinas_info = {}
    for nota in notas:
        if nota.disciplina.id not in disciplinas_info:
            disciplinas_info[nota.disciplina.id] = {
                'nome': nota.disciplina.nome,
                'notas': [],
                'frequencia': 0,
            }
        disciplinas_info[nota.disciplina.id]['notas'].append(nota.valor)
    
    # Calcular frequência por disciplina
    for freq in frequencias:
        if freq.disciplina.id in disciplinas_info:
            if freq.presente:
                disciplinas_info[freq.disciplina.id]['frequencia'] += 1
    
    # Calcular média geral
    todas_as_notas = [nota.valor for nota in notas]
    media_geral = sum(todas_as_notas) / len(todas_as_notas) if todas_as_notas else 0
    
    context = {
        'aluno': aluno,
        'disciplinas_info': disciplinas_info,
        'media_geral': media_geral,
    }
    return render(request, 'academico/boletim.html', context)
