# Guia Rápido de Instalação - EduBoletim

## Instalação Rápida (Linux/Mac)

```bash
# 1. Navegue até o diretório do projeto
cd eduboletim_project

# 2. Crie um ambiente virtual
python3 -m venv venv

# 3. Ative o ambiente virtual
source venv/bin/activate

# 4. Instale as dependências
pip install -r requirements.txt

# 5. Aplique as migrações
python manage.py migrate

# 6. Inicie o servidor
python manage.py runserver
```

## Instalação Rápida (Windows)

```bash
# 1. Navegue até o diretório do projeto
cd eduboletim_project

# 2. Crie um ambiente virtual
python -m venv venv

# 3. Ative o ambiente virtual
venv\Scripts\activate

# 4. Instale as dependências
pip install -r requirements.txt

# 5. Aplique as migrações
python manage.py migrate

# 6. Inicie o servidor
python manage.py runserver
```

## Acessar a Aplicação

- **URL Principal**: http://localhost:8000
- **Painel Administrativo**: http://localhost:8000/admin

## Credenciais Padrão

- **Usuário**: admin
- **Senha**: admin123

## Próximos Passos

1. Altere a senha do superusuário
2. Crie uma escola
3. Crie séries e turmas
4. Cadastre alunos e disciplinas
5. Comece a lançar notas e frequências

## Suporte

Para dúvidas, consulte o arquivo README.md
